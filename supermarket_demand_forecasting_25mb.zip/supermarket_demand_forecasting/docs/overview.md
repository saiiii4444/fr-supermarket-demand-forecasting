## Project design overview

The supermarket demand forecasting pipeline is organised into four main stages:

1. **Data ingestion:** raw transaction files (Excel or CSV) are loaded and cleaned.  Cancelled invoices and negative quantities can be removed.  Dates are parsed and a `Sales` column is computed from `Quantity × UnitPrice`.
2. **Feature engineering:** cleaned data is aggregated at a configurable frequency (daily, weekly or monthly).  Calendar features (month, day‑of‑week, day‑of‑year) are added along with lags and rolling statistics.  These features capture seasonality and short‑term trends.
3. **Modelling:** forecasting models (Prophet or ARIMA) are trained on the aggregated time series.  The models predict future sales for a configurable horizon.  Predictions and confidence intervals are stored for analysis.
4. **Dashboards:** interactive dashboards present historical sales, forecast curves and confidence intervals.  These can be exported as HTML files or imported into Power BI for further exploration.

Each stage is decoupled and invoked via a command‑line interface, allowing automation with task schedulers or integration into continuous deployment pipelines.  The modular design facilitates experimentation with alternative models or additional features without changing the overall flow.