"""Forecasting models for supermarket demand.

This module provides simple wrappers around forecasting models such as Prophet
and ARIMA.  It exposes a CLI to train a model on aggregated time‑series
features and generate future predictions.

Example usage::

    python -m src.modelling \
        --input_path data/processed/features.csv \
        --model prophet \
        --output_path data/processed/predictions.csv \
        --horizon 30
"""

from __future__ import annotations

import click
import pandas as pd
import numpy as np
from typing import Tuple

try:
    # Prophet moved from fbprophet to prophet
    from prophet import Prophet
except ImportError:
    try:
        from fbprophet import Prophet  # type: ignore
    except ImportError:
        Prophet = None  # type: ignore

import warnings
warnings.filterwarnings("ignore")


def train_prophet(df: pd.DataFrame, horizon: int = 30) -> pd.DataFrame:
    """Train a Prophet model and forecast future sales.

    Parameters
    ----------
    df : pd.DataFrame
        Data frame with columns `ds` (datetime) and `sales` (target).
    horizon : int, default 30
        Number of periods into the future to forecast.

    Returns
    -------
    pd.DataFrame
        Data frame containing historical actuals and forecasts for the
        specified horizon with columns `ds`, `yhat`, `yhat_lower`, `yhat_upper`.
    """
    if Prophet is None:
        raise RuntimeError("Prophet package is not installed. Install prophet or fbprophet.")

    df_train = df[["ds", "sales"]].rename(columns={"sales": "y"}).copy()
    m = Prophet(daily_seasonality=True, weekly_seasonality=True, yearly_seasonality=True)
    m.fit(df_train)
    future = m.make_future_dataframe(periods=horizon, freq=df_train["ds"].diff().dropna().mode()[0])
    forecast = m.predict(future)
    result = forecast[["ds", "yhat", "yhat_lower", "yhat_upper"]].copy()
    return result


def train_arima(df: pd.DataFrame, horizon: int = 30) -> pd.DataFrame:
    """Train a simple ARIMA model using statsmodels and forecast.

    This implementation uses an automatic ARIMA order search.  It may
    not scale well for large datasets, but serves as a baseline.
    """
    import statsmodels.api as sm
    y = df["sales"]
    # Auto ARIMA; choose order (1,1,1) for demonstration
    model = sm.tsa.ARIMA(y, order=(1, 1, 1))
    res = model.fit()
    forecast = res.forecast(steps=horizon)
    # Build result df with dates
    last_date = df["ds"].max()
    freq = df["ds"].diff().dropna().mode()[0]
    future_dates = pd.date_range(last_date + freq, periods=horizon, freq=freq)
    result = pd.DataFrame({"ds": future_dates, "yhat": forecast})
    result["yhat_lower"] = result["yhat"]
    result["yhat_upper"] = result["yhat"]
    return result


@click.command()
@click.option("--input_path", type=click.Path(exists=True), required=True, help="Path to the feature CSV with 'ds' and 'sales'.")
@click.option("--model", type=click.Choice(["prophet", "arima"]), default="prophet", show_default=True, help="Forecasting model to use.")
@click.option("--output_path", type=click.Path(), required=True, help="Path to write the predictions CSV.")
@click.option("--horizon", type=int, default=30, show_default=True, help="Number of periods into the future to forecast.")
def main(input_path: str, model: str, output_path: str, horizon: int) -> None:
    """Entry point for model training and forecasting.
    """
    df = pd.read_csv(input_path, parse_dates=["ds"])
    if model == "prophet":
        preds = train_prophet(df, horizon=horizon)
    else:
        preds = train_arima(df, horizon=horizon)
    preds.to_csv(output_path, index=False)
    click.echo(f"Forecasts saved to {output_path} (rows: {len(preds)})")


if __name__ == "__main__":
    main()