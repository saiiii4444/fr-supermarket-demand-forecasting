"""Feature engineering for demand forecasting.

This module aggregates transactional data into time‑series features suitable for
forecasting.  It provides a CLI to read a cleaned CSV, resample it at a
specified frequency (daily or weekly) and compute additional lags and
rolling statistics.

Example usage::

    python -m src.features \
        --input_path data/processed/retail_cleaned.csv \
        --output_path data/processed/features.csv \
        --frequency D
"""

from __future__ import annotations

import click
import pandas as pd
import numpy as np

FREQS = {
    "D": "D",  # daily
    "W": "W-MON",  # weekly (starting Monday)
    "M": "M",  # month end
}


def aggregate_sales(df: pd.DataFrame, freq: str = "D") -> pd.DataFrame:
    """Aggregate sales and quantity to a given frequency.

    Parameters
    ----------
    df : pd.DataFrame
        Cleaned transactional data containing at least the columns
        `InvoiceDate`, `Sales` and `Quantity`.
    freq : str, default 'D'
        Pandas offset alias (e.g. 'D' for daily, 'W' for weekly).

    Returns
    -------
    pd.DataFrame
        Data frame with aggregated sales and quantity indexed by date.
    """
    df = df.copy()
    df = df.set_index("InvoiceDate")
    agg = df.resample(freq).agg({"Sales": "sum", "Quantity": "sum"})
    agg = agg.rename(columns={"Sales": "sales", "Quantity": "quantity"})
    agg = agg.reset_index().rename(columns={"InvoiceDate": "ds"})
    return agg


def compute_time_features(df: pd.DataFrame) -> pd.DataFrame:
    """Add calendar time features and lags.

    Adds month, day‑of‑week and day‑of‑year features, along with common lags
    (7, 14, 28 days) and rolling means.
    """
    df = df.copy()
    df["month"] = df["ds"].dt.month
    df["dow"] = df["ds"].dt.dayofweek
    df["doy"] = df["ds"].dt.dayofyear

    # Lags and rolling means for sales
    for lag in [7, 14, 28]:
        df[f"lag_{lag}"] = df["sales"].shift(lag)
        df[f"rolling_mean_{lag}"] = df["sales"].shift(1).rolling(window=lag, min_periods=1).mean()

    # Fill missing values with zeros for lags
    df.fillna(0, inplace=True)
    return df


@click.command()
@click.option("--input_path", type=click.Path(exists=True), required=True, help="Path to the cleaned CSV.")
@click.option("--output_path", type=click.Path(), required=True, help="Path to write the feature CSV.")
@click.option("--frequency", type=click.Choice(list(FREQS.keys())), default="D", show_default=True, help="Aggregation frequency: D (daily), W (weekly) or M (monthly).")
def main(input_path: str, output_path: str, frequency: str) -> None:
    """Entry point for feature engineering.

    Loads cleaned data, aggregates to the specified frequency, creates calendar
    and lag features, and writes the result to CSV.
    """
    df = pd.read_csv(input_path, parse_dates=["InvoiceDate"])
    agg = aggregate_sales(df, freq=FREQS[frequency])
    features = compute_time_features(agg)
    features.to_csv(output_path, index=False)
    click.echo(f"Features saved to {output_path} (rows: {len(features)})")


if __name__ == "__main__":
    main()