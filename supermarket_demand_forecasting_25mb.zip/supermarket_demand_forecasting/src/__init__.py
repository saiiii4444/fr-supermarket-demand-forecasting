"""Supermarket Demand Forecasting package.

This package provides modules for data ingestion, feature engineering,
forecasting models and dashboards.
"""

__all__ = [
    "data_ingestion",
    "features",
    "modelling",
    "dashboard",
]