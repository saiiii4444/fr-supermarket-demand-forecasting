"""Data ingestion and cleaning for the supermarket demand forecasting project.

This module provides a command‑line interface (CLI) for loading the raw
transactional data from an Excel or CSV file, performing basic cleaning
(removing cancellations, dropping invalid rows, parsing dates) and saving
the result to a CSV file for downstream processing.

Example usage::

    python -m src.data_ingestion \
        --input_path data/raw/online_retail.xlsx \
        --output_path data/processed/retail_cleaned.csv \
        --drop_cancellations
"""

from __future__ import annotations

import click
import pandas as pd


def load_data(path: str) -> pd.DataFrame:
    """Load the raw data file.

    Supports Excel (.xlsx, .xls) and CSV.  The function infers the file type
    from the extension and uses the appropriate pandas reader.

    Parameters
    ----------
    path : str
        Path to the input file.

    Returns
    -------
    pd.DataFrame
        Data frame containing the raw data.
    """
    if path.lower().endswith(('.xls', '.xlsx')):
        df = pd.read_excel(path)
    else:
        df = pd.read_csv(path)
    return df


def clean_data(
    df: pd.DataFrame,
    drop_cancellations: bool = False,
    min_quantity: int | None = None,
) -> pd.DataFrame:
    """Clean the raw retail data.

    Parameters
    ----------
    df : pd.DataFrame
        Raw data.
    drop_cancellations : bool, default False
        If True, drop rows where `InvoiceNo` begins with 'C' (cancelled invoices).
    min_quantity : int or None, default None
        If provided, drop rows where `Quantity` is less than this threshold.

    Returns
    -------
    pd.DataFrame
        Cleaned data with parsed dates and an additional `Sales` column
        (Quantity × UnitPrice).
    """
    cleaned = df.copy()

    # Ensure expected columns exist
    required_cols = {
        "InvoiceNo",
        "StockCode",
        "Description",
        "Quantity",
        "InvoiceDate",
        "UnitPrice",
        "CustomerID",
        "Country",
    }
    missing = required_cols.difference(cleaned.columns)
    if missing:
        raise ValueError(f"Missing expected columns: {missing}")

    # Drop cancelled invoices
    if drop_cancellations:
        mask = ~cleaned["InvoiceNo"].astype(str).str.startswith("C", na=False)
        cleaned = cleaned.loc[mask].reset_index(drop=True)

    # Drop rows with non‑positive quantity if specified
    if min_quantity is not None:
        cleaned = cleaned.loc[cleaned["Quantity"] >= min_quantity].reset_index(drop=True)

    # Parse dates
    cleaned["InvoiceDate"] = pd.to_datetime(cleaned["InvoiceDate"], errors="coerce")
    cleaned = cleaned.dropna(subset=["InvoiceDate"]).reset_index(drop=True)

    # Ensure numeric types
    cleaned["Quantity"] = pd.to_numeric(cleaned["Quantity"], errors="coerce")
    cleaned["UnitPrice"] = pd.to_numeric(cleaned["UnitPrice"], errors="coerce")
    cleaned = cleaned.dropna(subset=["Quantity", "UnitPrice"]).reset_index(drop=True)

    # Compute sales
    cleaned["Sales"] = cleaned["Quantity"] * cleaned["UnitPrice"]

    return cleaned


def save_data(df: pd.DataFrame, path: str) -> None:
    """Save the cleaned data to CSV.

    Parameters
    ----------
    df : pd.DataFrame
        Data frame to save.
    path : str
        Destination path for the CSV.
    """
    df.to_csv(path, index=False)


@click.command()
@click.option("--input_path", type=click.Path(exists=True), required=True, help="Path to the raw input file (Excel or CSV).")
@click.option("--output_path", type=click.Path(), required=True, help="Path to write the cleaned CSV.")
@click.option("--drop_cancellations", is_flag=True, default=False, help="Drop invoices starting with 'C' (cancellations).")
@click.option("--min_quantity", type=int, default=1, show_default=True, help="Minimum quantity to keep. Rows with Quantity < min_quantity are dropped.")
def main(input_path: str, output_path: str, drop_cancellations: bool, min_quantity: int) -> None:
    """Entry point for the data ingestion script.

    This CLI loads a raw transaction file, cleans it and writes a CSV.
    """
    df = load_data(input_path)
    cleaned = clean_data(df, drop_cancellations=drop_cancellations, min_quantity=min_quantity)
    save_data(cleaned, output_path)
    click.echo(f"Cleaned data saved to {output_path} (rows: {len(cleaned)})")


if __name__ == "__main__":
    main()