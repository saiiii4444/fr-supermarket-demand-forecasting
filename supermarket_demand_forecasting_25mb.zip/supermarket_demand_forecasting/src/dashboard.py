"""Dashboard generation for supermarket demand forecasting.

This script reads the aggregated sales data and the forecast results and
produces an interactive line chart showing historical sales and forecasted
values.  The dashboard is saved as a self‑contained HTML file that can be
opened locally or embedded in other reports (e.g. Power BI).
"""

from __future__ import annotations

import click
import pandas as pd
import plotly.graph_objects as go


def build_dashboard(data_df: pd.DataFrame, forecast_df: pd.DataFrame) -> go.Figure:
    """Create a Plotly figure with actual and forecasted sales.

    Parameters
    ----------
    data_df : pd.DataFrame
        Historical data with columns `ds` and `sales`.
    forecast_df : pd.DataFrame
        Forecast data with columns `ds` and `yhat` (and optionally
        `yhat_lower` and `yhat_upper`).

    Returns
    -------
    go.Figure
        Plotly figure with actual and forecast traces.
    """
    fig = go.Figure()
    # Historical sales
    fig.add_trace(go.Scatter(
        x=data_df["ds"], y=data_df["sales"], mode="lines", name="Actual Sales"
    ))
    # Forecasted sales
    fig.add_trace(go.Scatter(
        x=forecast_df["ds"], y=forecast_df["yhat"], mode="lines", name="Forecast",
        line=dict(dash="dash")
    ))
    # Confidence intervals if available
    if {"yhat_lower", "yhat_upper"}.issubset(forecast_df.columns):
        fig.add_trace(go.Scatter(
            x=forecast_df["ds"].tolist() + forecast_df["ds"][::-1].tolist(),
            y=forecast_df["yhat_upper"].tolist() + forecast_df["yhat_lower"][::-1].tolist(),
            fill="toself", fillcolor="rgba(0,100,80,0.2)", line=dict(color="rgba(255,255,255,0)"),
            hoverinfo="skip", name="Confidence Interval"
        ))
    fig.update_layout(
        title="Historical Sales and Forecast",
        xaxis_title="Date",
        yaxis_title="Sales",
        legend=dict(x=0.01, y=0.99),
        hovermode="x unified",
    )
    return fig


@click.command()
@click.option("--data_path", type=click.Path(exists=True), required=True, help="Path to the aggregated feature CSV (contains 'ds' and 'sales').")
@click.option("--forecast_path", type=click.Path(exists=True), required=True, help="Path to the forecast CSV.")
@click.option("--output_path", type=click.Path(), default="dashboards/forecast_dashboard.html", show_default=True, help="Path to save the HTML dashboard.")
def main(data_path: str, forecast_path: str, output_path: str) -> None:
    """Generate an interactive dashboard as an HTML file."""
    data_df = pd.read_csv(data_path, parse_dates=["ds"])
    forecast_df = pd.read_csv(forecast_path, parse_dates=["ds"])
    fig = build_dashboard(data_df, forecast_df)
    # Ensure output directory exists
    import os
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    fig.write_html(output_path, include_plotlyjs="cdn")
    click.echo(f"Dashboard saved to {output_path}")


if __name__ == "__main__":
    main()